package Pckg1;

abstract class Shape {
	abstract public int getArea();
}

class Rectangle extends Shape {
	int len, wid;

	@Override
	public int getArea() {
		return len * wid;
	}
}

class Circle extends Shape {
	int radius;

	@Override
	public int getArea() {
		return (int) (3.14 * radius * radius);
	}
}

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle r1 =  new Rectangle();
		r1.wid = 12;
		r1.len = 20;
		
		System.out.println("Area of Rectangle is :"+r1.getArea());
		
		Circle c1 = new Circle();
		c1.radius = 14;
		
		System.out.println("Area of Circle is :"+c1.getArea());
	}

}
