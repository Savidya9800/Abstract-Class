/**
 * 
 */
/**
 * 
 */
module Abstract_Class_Demo {
}